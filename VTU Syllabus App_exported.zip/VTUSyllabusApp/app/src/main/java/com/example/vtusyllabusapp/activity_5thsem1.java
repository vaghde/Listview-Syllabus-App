package com.example.vtusyllabusapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class activity_5thsem1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity5sem);

        ListView listView = findViewById(R.id.listview);

        List<String> list = new ArrayList<>();
        list.add("System Software and Compiler Design");
        list.add("Computer Graphics");
        list.add("Web Technology");
        list.add("Data Mining and Data Warehousing");


        ArrayAdapter arrayAdapter = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_list_item_1,list);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(position==0){
                    //clicked ssc

                    startActivity(new Intent(activity_5thsem1.this,activity_ssc1.class));

                }
                else if(position==1)
                {
                    //clicked cg
                    startActivity(new Intent(activity_5thsem1.this,activity_cgv.class));
                }
                else if(position==2)
                {
                    //clicked wt
                    startActivity(new Intent(activity_5thsem1.this,activity_wt.class));
                }
                else if(position==3)
                {
                    //clicked wt
                    startActivity(new Intent(activity_5thsem1.this,activity_dmdw.class));
                }
                else
                {

                }
            }
        });



    }
}