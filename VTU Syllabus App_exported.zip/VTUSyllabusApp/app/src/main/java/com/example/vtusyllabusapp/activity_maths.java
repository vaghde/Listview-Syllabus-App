package com.example.vtusyllabusapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class activity_maths extends MainActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maths);
        ListView listView = findViewById(R.id.listview2);

        List<String> list = new ArrayList<>();
        list.add("M1");
        list.add("M2");
        list.add("M3");
        list.add("M4");

        ArrayAdapter arrayAdapter = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_list_item_1,list);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(position==0){
                    //clicked ssc

                    startActivity(new Intent(activity_maths.this,activity_m1.class));

                }
                else if(position==1)
                {
                    //clicked cg
                    startActivity(new Intent(activity_maths.this,activity_m2.class));
                }
                else if(position==2)
                {
                    //clicked wt
                    startActivity(new Intent(activity_maths.this,activity_m3.class));
                }
                else if(position==3)
                {
                    //clicked wt
                    startActivity(new Intent(activity_maths.this,activity_m4.class));
                }

                else
                {

                }
            }
        });


    }
}