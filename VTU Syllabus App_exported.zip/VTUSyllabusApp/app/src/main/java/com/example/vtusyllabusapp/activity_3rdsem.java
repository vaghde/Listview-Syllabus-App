package com.example.vtusyllabusapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class activity_3rdsem extends MainActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity4thsem);
        ListView listView = findViewById(R.id.listview);



        List<String> list = new ArrayList<>();
        list.add("M 3");
        list.add("DSA");
        list.add("ADE");
        list.add("CO");
        list.add("SE");
        list.add("DMS");


        ArrayAdapter arrayAdapter = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_list_item_1,list);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(position==0){
                    //clicked M3

                    startActivity(new Intent(activity_3rdsem.this,activity_m3.class));

                }
                else if(position==1)
                {
                    //clicked DSA
                    startActivity(new Intent(activity_3rdsem.this,activity_dsa.class));
                }
                else if(position==2)
                {
                    //clicked ADE
                    startActivity(new Intent(activity_3rdsem.this,activity_ade.class));
                }
                else if(position==3)
                {
                    //clicked CO
                    startActivity(new Intent(activity_3rdsem.this,activity_co.class));
                }
                else if(position==4)
                {
                    //clicked SE
                    startActivity(new Intent(activity_3rdsem.this,activity_se.class));
                }
                else if(position==5)
                {
                    //clicked DMS
                    startActivity(new Intent(activity_3rdsem.this,activity_dms.class));
                }
                else
                {

                }
            }
        });


    }
}
