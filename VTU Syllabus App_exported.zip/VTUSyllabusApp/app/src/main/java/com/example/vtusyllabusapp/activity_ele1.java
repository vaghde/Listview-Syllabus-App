package com.example.vtusyllabusapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class activity_ele1 extends MainActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ele1);
    }
}