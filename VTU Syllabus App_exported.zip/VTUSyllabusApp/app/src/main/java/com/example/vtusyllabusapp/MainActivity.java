package com.example.vtusyllabusapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ListView listView = findViewById(R.id.listview);

        List<String> list = new ArrayList<>();
        list.add("VTU Syllabus App INFO");
        list.add("MATHEMATICS");
        list.add("ENGLISH");
        list.add("1ST YEAR - CHEMISTRY CYCLE");
        list.add("1ST YEAR - PHYSICS CYCLE");
        list.add("3rd Sem");
        list.add("4th Sem");
        list.add("5th Sem");
        list.add("6th Sem");
        list.add("7th Sem");
        list.add("8th Sem");


        ArrayAdapter arrayAdapter = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_list_item_1,list);
        listView.setAdapter(arrayAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
               if(position==0){
                   //
                   startActivity(new Intent(MainActivity.this,appinfo.class));
               }
                else if(position==1){
                   //clicked
                   startActivity(new Intent(MainActivity.this,activity_maths.class));
               }
               else if(position==2){
                    //clicked
                    startActivity(new Intent(MainActivity.this,activity_english.class));
                }
               else if(position==3){
                    //clicked ssc

                    startActivity(new Intent(MainActivity.this,activity_1stsem.class));

                }
                else if(position==4)
                {
                    //clicked cg
                    startActivity(new Intent(MainActivity.this,activity_2ndsem.class));
                }
                else if(position==5)
                {
                    //clicked wt
                    startActivity(new Intent(MainActivity.this,activity_3rdsem.class));
                }
                else if(position==6)
                {
                    //clicked wt
                    startActivity(new Intent(MainActivity.this,activity_4thsem.class));
                }
                else if(position==7)
                {
                    //clicked wt
                    startActivity(new Intent(MainActivity.this,activity_5sem.class));
                }
                else if(position==8)
                {
                    //clicked wt
                    startActivity(new Intent(MainActivity.this,activity_6thsem.class));
                }
                else if(position==9)
                {
                    //clicked wt
                    startActivity(new Intent(MainActivity.this,activity_7thsem.class));
                }
                else if(position==10)
                {
                    //clicked wt
                    startActivity(new Intent(MainActivity.this,activity_8thsem.class));
                }
                else
                {

                }
            }
        });


    }
}