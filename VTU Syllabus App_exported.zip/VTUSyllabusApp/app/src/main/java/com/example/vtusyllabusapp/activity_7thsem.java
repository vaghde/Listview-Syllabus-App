package com.example.vtusyllabusapp;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class activity_7thsem extends MainActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ListView listView = findViewById(R.id.listview);

        List<String> list = new ArrayList<>();
        list.add("ARTIFICIAL INTELLIGENCE AND MACHINE LEARNING");
        list.add("BIG DATA ANALYTICS");
        list.add("Professional Elective: 2");
        list.add("Professional Elective:3");


        ArrayAdapter arrayAdapter = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_list_item_1,list);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(position==0){
                    //clicked ai

                    startActivity(new Intent(activity_7thsem.this,activity_ai.class));

                }
                else if(position==1)
                {
                    //clicked bd
                    startActivity(new Intent(activity_7thsem.this,activity_bd.class));
                }
                else if(position==2)
                {
                    //clicked pe1
                    startActivity(new Intent(activity_7thsem.this,activity_e1.class));
                }
                else if(position==3)
                {
                    //clicked pe2
                    startActivity(new Intent(activity_7thsem.this,activity_e2.class));
                }
                else
                {

                }
            }
        });


    }
}